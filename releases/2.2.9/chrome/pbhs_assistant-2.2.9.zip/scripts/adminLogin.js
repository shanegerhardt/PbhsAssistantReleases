chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.type === 'adminLogin') {
    login(message, sendResponse, message.tabId);
    return true;
  }
});

function login(message, callback, tabId) {
  var status = {
    completed: false,
    message: '',
  };
  if (window.location.pathname.indexOf('wp-login') == -1) {
    globalNavigateTab(globalGetBaseUrl() + '/admin', tabId);
  } else {
    var siteData = validateSite();
    if (siteData) {
      chrome.storage.local.get('credentials', function(result) {
        var userData = getCredentials(result, siteData.isCustomServer);
        if (userData) {
          globalFullPageNotification(siteData.message);
          document.getElementById('user_login').value = userData.user;
          document.getElementById('user_pass').value = userData.pass;
          document.close();
          document.getElementById('loginform').submit();
          status.completed = true;
          status.message = 'Logged In';
        } else {
          status.message = 'No Credentials';
        }
        callback(status);
      });
    } else {
      status.message = 'Not a PBHS website';
      callback(status);
    }
  }
}

function validateSite() {
  var validationMeta = document.querySelector('meta[name="pbhs:validate"]');
  if (!validationMeta || !validationMeta.content) {
    return false;
  }
  if (validationMeta.content === '2502953795e3b9974c0bdecb464fdd8b') {
    return {
      message: 'Logging you in to pbhs-sites...',
      isCustomServer: true,
    };
  }

  if (validationMeta.content === 'e28a2f50d84b1ae893531f2ebaa5aafc') {
    return {
      message: 'Logging you in to freewaysites...',
      isCustomServer: false,
    };
  }

  if (validationMeta.content === 'cf87ce38038f447938f76a543dc7fe9a') {
    return {
      message: 'Logging you in to local development...',
      isCustomServer: false,
    };
  }

  return false;
}

function getCredentials(result, isCustomServer) {
  if (!result || !result.credentials) {
    return false;
  }
  var credentials = result.credentials;
  if (
    isCustomServer &&
    credentials.pSitesUser.length &&
    credentials.pSitesPass.length &&
    credentials.pSitesUser != 'undefined' &&
    credentials.pSitesPass != 'undefined'
  ) {
    return {
      user: credentials.pSitesUser,
      pass: credentials.pSitesPass,
    };
  } else if (credentials.wUser && credentials.wPass) {
    return {
      user: credentials.wUser,
      pass: credentials.wPass,
    };
  }

  return false;
}
