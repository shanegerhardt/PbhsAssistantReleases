chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  switch (message.type) {
    case "adminLogin":
      login(message, sendResponse, message.tabId);
      return true;
      break;
  }
});

function login(message, callback, tabId) {
  var status = {
    completed: false,
    message: ""
  };
  if (window.location.pathname.indexOf("wp-login") == -1) {
    globalNavigateTab(globalGetBaseUrl() + "/admin", tabId);
  } else {
    chrome.storage.local.get("credentials", function(result) {
      if (
        chrome.runtime.lastError == null &&
        result.credentials.wUser &&
        result.credentials.wPass
      ) {
        var site = document.querySelector("#login h1 a").href;
        if (
          site.indexOf("freewaysites.com") !== -1 ||
          site.indexOf("pbhs.local") !== -1 ||
          site.indexOf(".test") !== -1 ||
          site.indexOf("localhost") !== -1
        ) {
          globalFullPageNotification("Logging you into freewaysites...");
          document.getElementById("user_login").value =
            result.credentials.wUser;
          document.getElementById("user_pass").value = result.credentials.wPass;
          document.close();
          document.getElementById("loginform").submit();
          status.completed = true;
          status.message = "Logged In";
        } else if (site.indexOf("pbhs-sites.com") !== -1) {
          globalFullPageNotification("Logging you into pbhs-sites...");
          if (
            result.credentials.pSitesUser.length &&
            result.credentials.pSitesPass.length &&
            result.credentials.pSitesUser != "undefined" &&
            result.credentials.pSitesPass != "undefined"
          ) {
            var username = result.credentials.pSitesUser;
            var password = result.credentials.pSitesPass;
          } else {
            var username = result.credentials.wUser;
            var password = result.credentials.wPass;
          }
          document.getElementById("user_login").value = username;
          document.getElementById("user_pass").value = password;
          document.close();
          document.getElementById("loginform").submit();
          status.completed = true;
          status.message = "Logged In";
        } else {
          status.message = "Not a PBHS website";
        }
      } else {
        status.message = "No credentials set";
      }
      callback(status);
    });
  }
}
