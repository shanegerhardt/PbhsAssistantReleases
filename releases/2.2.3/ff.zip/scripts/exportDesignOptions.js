chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  switch (message.type) {
    case "exportDesignOptions":
      exportDesignOptions(sendResponse);
      return true;
      break;
  }
});

function exportDesignOptions(callback) {
  var status = {
    completed: false,
    message: "Unknown error"
  }
  if(!globalIsWordpress()) {
    status.message = "Not a wordpress site";
    callback(status);
  }
  else if(!globalIsLoggedIn()) {
    status.message = "Login to use this function";
    callback(status);
  }
  else {
    chrome.storage.local.get('optionExportKey', function(result) {
      if(chrome.runtime.lastError == null && result.optionExportKey){
        window.location = window.location.protocol + '//' + window.location.hostname +
        window.location.pathname + globalGetOptionExportQuery('designOptions', result.optionExportKey, 'serialize');
        status.completed = true;
        status.message = "Options Exported";
      }
      else {
        status.message = "Need secret key";
      }
      callback(status);
    });
  }
}
