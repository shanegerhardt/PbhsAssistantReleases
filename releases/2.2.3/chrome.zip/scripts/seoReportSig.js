chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  switch (message.type) {
    case "seoReportSig":
      sign(sendResponse);
      return true;
      break;
  }
});

function sign(callback) {
  var status = {
    completed: false,
    message: 'Error Signing Report'
  }
  chrome.storage.local.get('seoReportSig', function (result) {
    if (chrome.runtime.lastError == null) {
      document.getElementById('Title').value = dateShortcodes(result.seoReportSig.title);
      if(true === result.seoReportSig.shouldPublish) {
        document.getElementById('Published').checked = true;
      }

      var injectedScript = document.createElement("script");
      var script = 'tinymce.editors.Description.menuItems.code.onclick();';
      script += 'document.activeElement.value += "' + result.seoReportSig.sig.toString() + '";';
      script += "document.querySelector('.mce-primary').click();";
      if(true === result.seoReportSig.shouldSave) {
        script += "document.querySelector('input[type=submit]').click()";
      }
      injectedScript.innerHTML = script;
      document.head.appendChild(injectedScript);
      status.completed = true;
      status.message = 'Report Signed';
    }
    callback(status);
  });
}

function dateShortcodes(text) {
  const MONTH_NAMES = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];
  var d = new Date();
  var m = d.getMonth();
  var lm = m - 1;
  var y = d.getFullYear();
  if (lm < 0) {
    lm = 11;
    y = y - 1;
  }

  text = text.replace('[LAST_MONTH]', MONTH_NAMES[lm])
  text = text.replace('[YEAR]', y);
  return text;
}