function isEmpty(obj) {
  for (var prop in obj) {
    if (obj.hasOwnProperty(prop)) return false;
  }
  return true && JSON.stringify(obj) === JSON.stringify({});
}

function escapeRegExp(str) {
  return str.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, '\\$1');
}

function replaceAll(str, find, replace) {
  return str.replace(new RegExp(escapeRegExp(find), 'g'), replace);
}

function loadLayout() {
  $.getJSON('plugins.json', function(data) {
    data = data.plugins[0];
    var layoutSection = $('.flex-row', '#layoutSection');
    for (var key in data) {
      if (data.hasOwnProperty(key)) {
        var option =
          '<div class="checkbox"><input type="checkbox" id="layout' +
          key +
          '" name="' +
          key +
          '" data-title="' +
          data[key]['title'] +
          '" data-type="' +
          data[key]['type'] +
          '"><label for="layout' +
          key +
          '"><div class="layout-container"><div class="layout-title">' +
          data[key]['title'] +
          '</div><div class="layout-description well">' +
          data[key]['description'] +
          '<i class="fa fa-check layout-enabled"></i><i class="fa fa-times layout-disabled"></i></div></div></label></div>';
        $(layoutSection).append(option);
      }
    }
  });
  showSelectedBoxes();
}

function updateStatus(message, classes, devMessage) {
  if (devMessage) {
    console.log(devMessage);
  }
  document.getElementById('statusText').innerText = message;
  document.getElementById('status').className = classes;
}

function loadCredentials() {
  chrome.storage.local.get('credentials', function(result) {
    if (chrome.runtime.lastError == null && !isEmpty(result)) {
      document.getElementById('wUser').value = result.credentials.wUser;
      document.getElementById('wPass').value = result.credentials.wPass;

      if (result.credentials.pSitesUser && result.credentials.pSitesPass) {
        document.getElementById('pSitesUser').value =
          result.credentials.pSitesUser;
        document.getElementById('pSitesPass').value =
          result.credentials.pSitesPass;
      }
    }
  });
}

function loadOptionExportKey() {
  chrome.storage.local.get('optionExportKey', function(result) {
    if (chrome.runtime.lastError == null && !isEmpty(result)) {
      document.getElementById('optionExportKey').value = result.optionExportKey;
    }
  });
}

function loadPluginOptions() {
  chrome.storage.local.get('seoReportSig', function(result) {
    if (chrome.runtime.lastError == null && !isEmpty(result)) {
      document.getElementById('seoReportSigTitle').value =
        result.seoReportSig.title;
      document.getElementById('seoReportSigContent').value =
        result.seoReportSig.sig;
      if (result.seoReportSig.shouldPublish) {
        document.getElementById('seoReportSigPublish').checked = true;
      }
      if (result.seoReportSig.shouldSave) {
        document.getElementById('seoReportSigSave').checked = true;
      }
    }
  });
}

function loadPlugins() {
  function createMarkup() {
    var data = null;
    var markup = '';
    console.log(this);
    if ((this.status = 200)) {
      try {
        var data = this.response;
      } catch (e) {
        updateStatus('Error parsing plugins.json', 'error', e);
      }
      if (data === null) return;

      for (var key in data) {
        if (data.hasOwnProperty(key)) {
          markup += '<div class="spacer">';
          markup += `<input id="layout${key}" name="${key}" data-title="${
            data[key]['title']
          }" data-type="${data[key]['type']}" type="checkbox">`;
          markup += `<label for="layout${key}">${data[key]['title']}</label>`;
          markup += `<div class="spacer-double">${
            data[key]['description']
          }</div>`;
          markup += '</div>';
        }
      }
      document.getElementById('plugins').innerHTML = markup;
      showSelectedPlugins();
    } else {
      updateStatus(
        'Error downloading plugins.json',
        'error',
        'status: ' + this.status
      );
    }
  }

  var request = new XMLHttpRequest();
  request.open('GET', 'plugins.json', true);
  request.responseType = 'json';
  request.addEventListener('load', createMarkup);
  request.send();
}

function showSelectedPlugins() {
  chrome.storage.local.get('layout', function(result) {
    for (var key in result['layout']) {
      if (result['layout'].hasOwnProperty(key)) {
        var element = document.querySelector(
          `input[name="${result['layout'][key]['name']}"]`
        );
        if (element) {
          element.checked = true;
        }
      }
    }
  });
}

function saveOptions() {
  var credentials = {
    wUser: document.getElementById('wUser').value,
    wPass: document.getElementById('wPass').value,
    pSitesUser: document.getElementById('pSitesUser').value,
    pSitesPass: document.getElementById('pSitesPass').value
  };
  var optionExportKey = document.getElementById('optionExportKey').value;
  layout = [];

  var activePlugins = document
    .getElementById('plugins')
    .querySelectorAll('input:checked');

  activePlugins.forEach(function(element, index, list) {
    if (element.checked) {
      layout.push({
        name: element.name,
        title: element.dataset.title,
        type: element.dataset.type
      });
    }
  });

  var seoReportSig = {
    title: document.getElementById('seoReportSigTitle').value,
    sig: replaceAll(
      document.getElementById('seoReportSigContent').value,
      '"',
      "'"
    ),
    shouldPublish: document.getElementById('seoReportSigPublish').checked,
    shouldSave: document.getElementById('seoReportSigSave').checked
  };

  chrome.storage.local.set(
    {
      optionExportKey: optionExportKey,
      credentials: credentials,
      layout: layout,
      seoReportSig: seoReportSig
    },
    function() {
      if (chrome.runtime.lastError == null) {
        updateStatus('Options saved successfully', 'success');
        setTimeout(() => {
          updateStatus('Set options below', 'normal');
        }, 5000);
      } else {
        updateStatus(
          'Error while saving options',
          'error',
          chrome.runtime.lastError
        );
      }
    }
  );
}

loadPlugins();
loadCredentials();
loadOptionExportKey();
loadPluginOptions();
document.getElementById('save').addEventListener('click', saveOptions);
