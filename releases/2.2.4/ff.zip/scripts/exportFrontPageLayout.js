chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  switch (message.type) {
    case "exportFrontPageLayout":
      exportFrontPageLayout(sendResponse);
      return true;
      break;
  }
});

function exportFrontPageLayout(callback) {
  var status = {
    completed: false,
    message: "Unknown Error"
  }
  if(!globalIsWordpress()) {
    status.message = "Not a wordpress site";
    callback(status);
  }
  else if(!globalIsLoggedIn()) {
    status.message = "Login to use this function";
    callback(status);
  }
  else {
    chrome.storage.local.get('optionExportKey', function(result) {
      if(chrome.runtime.lastError == null && result.optionExportKey){
        window.location = window.location.protocol + '//' + window.location.hostname +
        window.location.pathname + globalGetOptionExportQuery('pbhs_layout_front_page', result.optionExportKey, 'serialize');;
        status.completed = true;
        status.message = "Layout Exported";
      }
      else {
        status.message = "Need secret key";
      }
      callback(status);
    });
    
  }
}
