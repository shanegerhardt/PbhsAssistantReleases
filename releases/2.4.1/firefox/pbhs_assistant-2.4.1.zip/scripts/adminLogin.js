chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.type === 'adminLogin') {
    login(message, sendResponse, message.tabId);
    return true;
  }
});

function login(message, callback, tabId) {
  var status = {
    completed: false,
    message: '',
  };
  if (window.location.pathname.indexOf('wp-login') == -1) {
    globalNavigateTab(globalGetBaseUrl() + '/admin', tabId);
  } else {
    var siteData = validateSite();
    if (siteData) {
      chrome.storage.local.get('credentials', function (result) {
        var userData = getCredentials(result, siteData.userKey, siteData.pKey);
        if (userData) {
          globalFullPageNotification(siteData.message);
          document.getElementById('user_login').value = userData.user;
          document.getElementById('user_pass').value = userData.pass;
          document.close();
          document.getElementById('loginform').submit();
          status.completed = true;
          status.message = 'Logged In';
        } else {
          status.message = 'No Credentials';
        }
        callback(status);
      });
    } else {
      status.message = 'Not a PBHS website';
      callback(status);
    }
  }
}

function validateSite() {
  var validationMeta = document.querySelector('meta[name="pbhs:validate"]');
  validationMetaMap = {
    '2502953795e3b9974c0bdecb464fdd8b': {
      message: 'Logging you in to pbhs-sites...',
      userKey: 'pSitesUser',
      pKey: 'pSitesPass',
    },
    e28a2f50d84b1ae893531f2ebaa5aafc: {
      message: 'Logging you in to freewaysites...',
      userKey: 'wUser',
      pKey: 'wPass',
    },
    cf87ce38038f447938f76a543dc7fe9a: {
      message: 'Logging you in to local development...',
      userKey: 'wUser',
      pKey: 'wPass',
    },
    '8f13f4c3452998399dd17f7097b451a9': {
      message: 'Logging you in to development...',
      userKey: 'devUser',
      pKey: 'devPass',
    },
    b7563be9a2ec693a38727a0dbe22629d: {
      message: 'Logging you in to staging...',
      userKey: 'stagUser',
      pKey: 'stagPass',
    },
    a537bd4ca63e81579e0837aaaaead637: {
      message: 'Logging you in to production...',
      userKey: 'prodUser',
      pKey: 'prodPass',
    },
  };
  if (
    !validationMeta ||
    !validationMeta.content ||
    !validationMetaMap.hasOwnProperty(validationMeta.content)
  ) {
    return false;
  }

  return validationMetaMap[validationMeta.content];
}

function getCredentials(result, userKey, pKey) {
  if (!result || !result.credentials) {
    return false;
  }
  var credentials = result.credentials;
  if (
    credentials[userKey] !== undefined &&
    credentials[pKey] !== undefined &&
    credentials[userKey].length &&
    credentials[pKey].length
  ) {
    return {
      user: credentials[userKey],
      pass: credentials[pKey],
    };
  } else if (credentials.wUser && credentials.wPass) {
    return {
      user: credentials.wUser,
      pass: credentials.wPass,
    };
  }

  return false;
}
