chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (message.type === 'themeInfo') {
    getThemeInfo(sendResponse);
    return true;
  }
});

function getThemeInfo(callback) {
  var status = {
    completed: true,
    message: '',
  };
  status.message = 'Theme: ' + globalGetThemeFolderName();
  var serverInfo = globalGetServerInfo();
  if (serverInfo !== false) {
    status.message += `<br /> Server: ${serverInfo.server} ${serverInfo.serverLocation}`;
  }
  callback(status);
}
